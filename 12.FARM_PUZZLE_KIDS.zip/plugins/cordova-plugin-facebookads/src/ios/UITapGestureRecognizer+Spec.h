//
//  UITapGestureRecognizer.h
//  TestFacebookAds
//
//  Created by Xie Liming on 15/10/18.
//
//

#import <Foundation/Foundation.h>

@interface UITapGestureRecognizer (SpecPrivate)

-(void)performTapWithView:(UIView *)view andPoint:(CGPoint)point;

@end
